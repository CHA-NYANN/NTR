KOUSEIKAN - EMPAT TANGAN & DUA ANIMASI PILIHAN

Sumber gambar: TIGA PNG yang diberikan user (bukan gambar ulang).
Canvas: 1536x864. Ada 20 frame pada 12 FPS (sekitar 1,67 detik) per pilihan.

ISI
- background_pilihan_asli_1536x864.png = gambar awal asli (dipotong 1 px di bawah dari 1536x865 agar tepat 16:9)
- sprites/cropped/ = 4 sprite tangan PNG transparan, ukuran mengikuti kontur gambar.
- sprites/full_canvas/ = 4 sprite RGBA transparan dalam canvas 1536x864 (posisinya sudah benar).
- animation/pilih_yutaka/full_scene_frames/ = 20 frame PNG adegan penuh.
- animation/pilih_chiasa/full_scene_frames/ = 20 frame PNG adegan penuh.
- animation/*/player_only_frames/ = 20 frame transparan tangan pemain saja, untuk ditempel di atas background.
- preview/*.gif = pratinjau, kualitas dikurangi untuk ukuran file.
- metadata.json = info canvas, waktu, koordinat crop.

Frame_000 adalah adegan awal; pemain mulai muncul dari bawah pada frame 001; pose akhir ditahan di frame 016-019.
Untuk Ren'Py gunakan background statis + overlay frame dari player_only_frames setiap 1/12 detik.
Gerakan dibuat dari translasi sprite tangan asli dengan easing. Tidak ada gambar jari baru atau animasi genggaman.
Masking transparan dibuat otomatis. Tinjau kontur jika hendak meletakkan sprite pada latar putih/terang.
Belum diintegrasikan ke repository, tidak ada modifikasi code atau canon.
